#!/bin/bash

export PROGRAM=SPEED-MDOF
export OUTPUT=debug.out 
export TOTAL_MPI_PROCESSES=4
export THREADS=1
 
let NCORES=$TOTAL_MPI_PROCESSES
echo "Running on $NCORES cores"
echo "Job started at `date`"

time mpirun -np $TOTAL_MPI_PROCESSES  -x OMP_NUM_THREADS=$THREADS  $PROGRAM >& $OUTPUT
wait

